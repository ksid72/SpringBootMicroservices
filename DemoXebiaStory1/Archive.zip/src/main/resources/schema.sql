DROP TABLE IF EXISTS article_entity;
  


